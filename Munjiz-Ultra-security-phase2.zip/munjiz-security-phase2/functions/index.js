'use strict';

const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { logger } = require('firebase-functions');

initializeApp();
const db = getFirestore();
const DAY_MS = 24 * 60 * 60 * 1000;
const MAX_PER_EVENT = 25;
const MAX_PER_DAY = 100;
const ALLOWED_REASONS = new Set(['task', 'focus', 'challenge']);

function validId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_-]{8,120}$/.test(value);
}
function levelFromXp(xp) {
  // Keep this formula synchronized with the client game's levelFromXp().
  const total = Math.max(0, Number(xp) || 0); let level = 1; while (level < 1000 && total >= Math.floor(100 * Math.pow(level + 1, 1.8))) level++; return level;
}

/**
 * Awards a bounded amount of XP from a trusted server transaction.
 * Important: this is a hardening layer, not proof that a task was truly completed.
 * The client cannot exceed per-event or daily caps; eventId makes retries idempotent.
 */
exports.awardStudyReward = onCall({ enforceAppCheck: false, maxInstances: 10 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const uid = request.auth.uid;
  const { reason, eventId, requestedAmount } = request.data || {};
  if (!ALLOWED_REASONS.has(reason)) throw new HttpsError('invalid-argument', 'Unsupported reward reason.');
  if (!validId(eventId)) throw new HttpsError('invalid-argument', 'Invalid event ID.');
  const amount = Math.max(0, Math.min(MAX_PER_EVENT, Math.floor(Number(requestedAmount) || 0)));
  if (amount < 1) throw new HttpsError('invalid-argument', 'Reward amount must be positive.');

  const now = Date.now();
  const dayKey = new Date(now).toISOString().slice(0, 10);
  const statsRef = db.doc(`userStats/${uid}`);
  const eventRef = db.doc(`userStats/${uid}/rewardEvents/${eventId}`);
  const mainRef = db.doc(`users/${uid}/data/main`);
  const profileRef = db.doc(`publicProfiles/${uid}`);

  const result = await db.runTransaction(async (tx) => {
    const [statsSnap, eventSnap, mainSnap] = await Promise.all([
      tx.get(statsRef), tx.get(eventRef), tx.get(mainRef)
    ]);
    if (eventSnap.exists) {
      const existing = statsSnap.exists ? statsSnap.data() : {};
      return { duplicate: true, xp: Number(existing.xp) || 0, level: levelFromXp(existing.xp || 0) };
    }

    const legacyGame = mainSnap.exists ? (((mainSnap.data() || {}).state || {}).game || {}) : {};
    const stats = statsSnap.exists ? statsSnap.data() : { xp: Math.max(0, Number(legacyGame.xp) || 0), level: Math.max(1, Number(legacyGame.level) || 1), dayKey, dailyEarned: 0 };
    const earnedToday = stats.dayKey === dayKey ? Math.max(0, Number(stats.dailyEarned) || 0) : 0;
    const grant = Math.min(amount, Math.max(0, MAX_PER_DAY - earnedToday));
    if (grant < 1) throw new HttpsError('resource-exhausted', 'Daily XP limit reached.');
    const xp = Math.max(0, Number(stats.xp) || 0) + grant;
    const level = levelFromXp(xp);

    tx.set(statsRef, {
      xp, level, dayKey, dailyEarned: earnedToday + grant,
      updatedAt: FieldValue.serverTimestamp()
    }, { merge: true });
    tx.create(eventRef, {
      reason, requestedAmount: amount, grantedAmount: grant,
      createdAt: FieldValue.serverTimestamp()
    });

    // The server owns the authoritative XP fields in the existing app state document.
    if (mainSnap.exists) {
      tx.update(mainRef, { 'state.game.xp': xp, 'state.game.level': level, updatedAt: now });
    }
    tx.set(profileRef, { xp, level, updatedAt: new Date(now).toISOString(), public: true }, { merge: true });
    return { duplicate: false, xp, level, granted: grant };
  });
  logger.info('XP reward processed', { uid, reason, duplicate: result.duplicate });
  return result;
});

/** A developer-only callable for sensitive administration. Never trust a client flag. */
exports.setDeveloperXp = onCall({ enforceAppCheck: false, maxInstances: 5 }, async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in required.');
  const actor = request.auth.uid;
  const actorSnap = await db.doc(`developers/${actor}`).get();
  if (!actorSnap.exists || actorSnap.data().role !== 'developer') {
    throw new HttpsError('permission-denied', 'Developer access required.');
  }
  const { targetUid, xp } = request.data || {};
  const amount = Math.max(0, Math.floor(Number(xp)));
  if (typeof targetUid !== 'string' || !targetUid || !Number.isFinite(amount) || amount > 100000000) {
    throw new HttpsError('invalid-argument', 'Invalid target or XP.');
  }
  const level = levelFromXp(amount);
  const statsRef = db.doc(`userStats/${targetUid}`);
  const mainRef = db.doc(`users/${targetUid}/data/main`);
  const profileRef = db.doc(`publicProfiles/${targetUid}`);
  await db.runTransaction(async (tx) => {
    const main = await tx.get(mainRef);
    tx.set(statsRef, { xp: amount, level, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    if (main.exists) tx.update(mainRef, { 'state.game.xp': amount, 'state.game.level': level, updatedAt: Date.now() });
    tx.set(profileRef, { xp: amount, level, updatedAt: new Date().toISOString(), public: true }, { merge: true });
  });
  return { ok: true, xp: amount, level };
});
